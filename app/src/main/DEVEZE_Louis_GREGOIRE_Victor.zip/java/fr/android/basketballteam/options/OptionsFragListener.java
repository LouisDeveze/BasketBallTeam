package fr.android.basketballteam.options;

public interface OptionsFragListener {
    void onLanguageSelected(String Language);
}
