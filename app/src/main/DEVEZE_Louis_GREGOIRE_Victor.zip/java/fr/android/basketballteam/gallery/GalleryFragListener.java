package fr.android.basketballteam.gallery;

public interface GalleryFragListener {
}
